const express = require('express');
const router = express.Router();
const UserController = require('../controller/UserController');

router.post('/signup', UserController.registerUser);
router.post('/signin', UserController.authUser);
router.get('/admin', UserController.getAllUsers);

module.exports = router;